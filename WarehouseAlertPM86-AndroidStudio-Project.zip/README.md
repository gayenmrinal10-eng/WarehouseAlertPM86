# Warehouse Alert – PM86 (local Wi-Fi prototype)

This Android Studio project contains a simple supervisor broadcaster and an associate receiver.
It sends a UDP broadcast to `255.255.255.255:45454` on the local network. No SIM, cloud account,
or internet connection is used for message transport.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the resulting APK from `app/build/outputs/apk/debug/app-debug.apk`.

## Deploy
- Install on the supervisor phone and all PM86 scanners.
- On each PM86, open the app, select Associate – Receive alerts, tap START RECEIVING ALERTS,
  and allow notifications.
- On the supervisor phone, select Supervisor – Send alerts, type a message, tap SEND TO ALL SCANNERS.
- Keep receiver devices powered on and the receiver service running. Disable battery optimization
  for this app on each scanner if your device policy permits it.

## Important network limitations
This is a prototype, not an SMS service. UDP broadcast only works if the Wi-Fi access point
allows client-to-client communication and broadcast traffic. Guest Wi-Fi, AP/client isolation,
VLAN separation, firewall rules, and some enterprise Wi-Fi configurations may block it.
Ask warehouse IT to confirm peer-to-peer traffic is allowed on the scanner SSID.
Test with 2 devices first, then roll out to 50. Do not use for emergency/safety-critical alerts.
The current prototype does not provide delivery receipts, authentication, encryption, or admin controls.
For production use, add a secured local server or managed push system and obtain IT approval.
