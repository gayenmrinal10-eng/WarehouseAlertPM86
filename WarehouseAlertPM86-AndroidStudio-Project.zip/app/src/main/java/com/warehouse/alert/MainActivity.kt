package com.warehouse.alert

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class MainActivity : Activity() {
    private val port = 45454
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = 1; setPadding(28, 36, 28, 24) }
        root.addView(TextView(this).apply { text = "WAREHOUSE ALERT • PM86"; textSize = 24f })
        root.addView(TextView(this).apply { text = "Local Wi-Fi broadcast • up to 50 scanners"; textSize = 14f })
        val role = Spinner(this)
        role.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Supervisor – Send alerts", "Associate – Receive alerts"))
        root.addView(role)
        val message = EditText(this).apply { hint = "Type announcement for all associates"; minLines = 3; gravity = 48 }
        root.addView(message)
        val send = Button(this).apply { text = "SEND TO ALL SCANNERS" }
        root.addView(send)
        val listen = Button(this).apply { text = "START RECEIVING ALERTS" }
        root.addView(listen)
        val status = TextView(this).apply { text = "Choose Supervisor on the supervisor phone. Choose Associate on each PM86." }
        root.addView(status)
        send.setOnClickListener {
            val text = message.text.toString().trim()
            if (text.isEmpty()) { status.text = "Enter a message first."; return@setOnClickListener }
            Thread {
                try {
                    val data = ("WAREHOUSE_ALERT:" + text.take(500)).toByteArray(Charsets.UTF_8)
                    DatagramSocket().use { socket ->
                        socket.broadcast = true
                        val packet = DatagramPacket(data, data.size, InetAddress.getByName("255.255.255.255"), port)
                        socket.send(packet)
                    }
                    runOnUiThread { status.text = "Broadcast sent. Delivery depends on warehouse Wi-Fi allowing device-to-device traffic." }
                } catch (e: Exception) { runOnUiThread { status.text = "Send failed: ${e.message}" } }
            }.start()
        }
        listen.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 8)
            }
            startForegroundService(Intent(this, ListenerService::class.java))
            status.text = "Receiver service started. Keep app notifications enabled."
        }
        setContentView(root)
    }
}
