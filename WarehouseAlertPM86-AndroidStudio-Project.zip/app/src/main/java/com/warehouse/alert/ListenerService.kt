package com.warehouse.alert

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import java.net.DatagramPacket
import java.net.DatagramSocket

class ListenerService : Service() {
    @Volatile private var running = true
    private var lock: WifiManager.MulticastLock? = null
    override fun onCreate() {
        super.onCreate()
        val channelId = "warehouse_alerts"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "Warehouse alerts", NotificationManager.IMPORTANCE_HIGH))
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Warehouse Alert is listening")
            .setContentText("Waiting for supervisor announcements on local Wi-Fi")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(7, notification)
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        lock = wifi.createMulticastLock("warehouse-alert-lock").apply { setReferenceCounted(false); acquire() }
        Thread {
            try {
                DatagramSocket(45454).use { socket ->
                    socket.broadcast = true
                    val buffer = ByteArray(2048)
                    while (running) {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val msg = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        if (msg.startsWith("WAREHOUSE_ALERT:")) showAlert(msg.removePrefix("WAREHOUSE_ALERT:"))
                    }
                }
            } catch (_: Exception) { }
        }.start()
    }
    private fun showAlert(message: String) {
        val channelId = "warehouse_alerts"
        val n = Notification.Builder(this, channelId)
            .setContentTitle("WAREHOUSE TEAM ALERT")
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(Notification.PRIORITY_MAX)
            .setAutoCancel(true).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
    override fun onDestroy() { running = false; try { lock?.release() } catch (_: Exception) {}; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
